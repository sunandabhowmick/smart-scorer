"""
Prompt Builder — the scoring engine. Edit to change how AI scores.

Key design points
-----------------
- The Python layer (response_parser.apply_scoring_rules) is the source
  of truth for: overall_score, technical-score ceiling, missing-skill
  count, and the SHORTLIST/REVIEW/PASS recommendation. Whatever the AI
  returns for these is overwritten if it disagrees with our rules.
  The prompt still asks the AI to compute them so we have a sanity
  check, but it's no longer the authority.
- Resume compression is delegated to services.ai.resume_compressor,
  which is section-aware and never drops the education section.
- The literal Must-Have skill check is computed in Python before
  prompting (response_parser.check_must_have_presence) and its result
  is injected verbatim into the prompt so the AI cannot disagree
  about which skills were "found".
"""
from typing import Dict, List, Optional

from services.ai.resume_compressor import compress_resume


SYSTEM_PROMPT = """You are a strict ATS scoring assistant for HYROI Solutions.
Return structured JSON ONLY. No conversational text. No markdown.

════════════════════════════════════════
RULE 1 — MUST HAVE SKILL DETECTION
════════════════════════════════════════

The user prompt contains a section called "MUST HAVE SKILL CHECK
(authoritative)". That section is the truth. It tells you exactly
which Must Have skills were found in the resume by literal keyword
match, and which were not.

You MUST use those findings as-is. Do NOT:
  ✗ Mark a skill as found that the check says is missing.
  ✗ Mark a skill as missing that the check says is found.
  ✗ Infer a skill from related work, adjacent tools, or "they probably know it".

If you disagree with the check, you are wrong. The check is run by
deterministic Python code; your job is to score, not to overrule it.

════════════════════════════════════════
RULE 2 — TECHNICAL SCORE CEILING (MANDATORY)
════════════════════════════════════════

Use the missing count from the MUST HAVE SKILL CHECK section. Apply
the corresponding ceiling. The ceiling is a HARD upper bound — your
technical score MUST be ≤ the ceiling.

  0 missing → no ceiling (score 0–100)
  1 missing → technical score ≤ 75
  2 missing → technical score ≤ 50
  3 missing → technical score ≤ 35
  4+missing → technical score ≤ 20

These caps are absolute. Strong experience, certifications, or domain
fit do NOT raise the ceiling. Note: Python will re-apply this ceiling
after you respond, so any violation will be silently corrected — but
your reasoning will look inconsistent if you ignore the rule.

In technical.reasoning, explicitly state:
  "X Must Have skill(s) missing: [names]. Ceiling applied: technical ≤ Y."

════════════════════════════════════════
RULE 3 — SCORING THE OTHER FOUR CATEGORIES
════════════════════════════════════════

Score each of these 0–100 independently, on its own merits:

  experience  — quality > quantity. Product company, leadership,
                career progression, domain relevance all count.
                Years alone do not.
  education   — match against the JD's education requirement.
                Score 0 only if education is genuinely absent or
                mismatched, not because you couldn't find the
                section. The resume preserves education explicitly.
  soft_skills — communication, collaboration, ownership signals
                visible in the resume. Be conservative if not stated.
  stability   — average tenure, job-hopping signals. Do NOT penalise
                clear promotions or role changes within the same
                company. Flag only if avg tenure < 1.5 yrs AND no
                visible progression.

════════════════════════════════════════
RULE 4 — OVERALL SCORE & RECOMMENDATION
════════════════════════════════════════

You will provide an overall_score and a recommendation, but be aware
that Python recalculates overall_score as the weighted average of
your 5 category scores (using the weights in the user prompt) and
re-derives the recommendation from the JD thresholds. So just compute
them honestly — your output here is a sanity check, not the final
answer.

════════════════════════════════════════
RETURN THIS EXACT JSON (no extra keys, no markdown):
════════════════════════════════════════

{
  "overall_score": <0-100, your estimate; Python will recalculate>,
  "recommendation": "<SHORTLIST|REVIEW|PASS>",
  "category_scores": {
    "technical":   { "score": <0-100>, "reasoning": "<list each Must Have: found/not found per the CHECK; state ceiling applied>" },
    "experience":  { "score": <0-100>, "reasoning": "<1-2 sentences>" },
    "education":   { "score": <0-100>, "reasoning": "<1-2 sentences>" },
    "soft_skills": { "score": <0-100>, "reasoning": "<1-2 sentences>" },
    "stability":   { "score": <0-100>, "reasoning": "<1-2 sentences>" }
  },
  "matched_skills": ["<copy from CHECK 'found' list>"],
  "missing_skills": ["<copy from CHECK 'missing' list>"],
  "red_flags":  [],
  "highlights": [],
  "ai_reasoning": "<Lead with which Must Have skills were found/missing per the CHECK and the ceiling applied. Then 2-3 sentences of overall assessment.>"
}"""


def build_user_prompt(
    resume_text: str,
    jd: Dict,
    candidate_name: str = "Unknown",
    must_have_check: Optional[Dict[str, List[str]]] = None,
    resume_budget: int = 3000,
) -> str:
    """
    Build the user prompt sent to the AI.

    Parameters
    ----------
    resume_text : str
        Full extracted resume text.
    jd : dict
        Job description config (from Supabase).
    candidate_name : str
        Display name for the candidate.
    must_have_check : dict, optional
        Result of response_parser.check_must_have_presence().
        Has shape {"found": [...], "missing": [...]}.
        If omitted, the prompt still works but the AI loses the
        authoritative ground-truth signal.
    resume_budget : int
        Character budget for the compressed resume.
    """
    weights = jd.get("scoring_weights", {
        "technical": 40, "experience": 25,
        "education": 10, "soft_skills": 15, "stability": 10
    })

    shortlist_threshold = (
        jd.get("shortlist_threshold")
        or weights.get("shortlist_threshold")
        or 75
    )
    review_threshold = (
        jd.get("review_threshold")
        or weights.get("review_threshold")
        or 55
    )
    min_technical = (
        jd.get("minimum_technical_score")
        or weights.get("minimum_technical_score")
        or None
    )

    skill_importance = jd.get("skill_importance", {})
    required_skills = jd.get("required_skills", [])

    must_have: List[str] = []
    good_to_have: List[str] = []
    bonus: List[str] = []

    for skill in required_skills:
        name = skill.get("skill", skill) if isinstance(skill, dict) else skill
        imp = skill_importance.get(name, "must")
        if imp == "must":
            must_have.append(name)
        elif imp == "good":
            good_to_have.append(name)
        else:
            bonus.append(name)

    nice_to_have = jd.get("nice_to_have_skills", [])
    custom = jd.get("custom_instructions", "").strip()

    # Section-aware compression that always preserves education.
    resume_compressed = compress_resume(resume_text, budget=resume_budget)

    # ---- Must Have skill check block (authoritative) ------------------
    check_block = ""
    if must_have_check is not None and must_have:
        found = must_have_check.get("found", [])
        missing = must_have_check.get("missing", [])
        n_missing = len(missing)
        if n_missing == 0:
            ceiling_line = "  Ceiling: NONE (no Must Have skills missing)"
        elif n_missing == 1:
            ceiling_line = "  Ceiling: technical score MUST be ≤ 75"
        elif n_missing == 2:
            ceiling_line = "  Ceiling: technical score MUST be ≤ 50"
        elif n_missing == 3:
            ceiling_line = "  Ceiling: technical score MUST be ≤ 35"
        else:
            ceiling_line = "  Ceiling: technical score MUST be ≤ 20"

        check_block = f"""

MUST HAVE SKILL CHECK (authoritative — computed by Python, do not override):
  Found in resume    ({len(found)}): {', '.join(found) if found else 'none'}
  Missing from resume ({n_missing}): {', '.join(missing) if missing else 'none'}
{ceiling_line}
  Use these lists EXACTLY as your matched_skills / missing_skills."""

    # ---- Build the prompt --------------------------------------------
    prompt = f"""CANDIDATE: {candidate_name}
JOB TITLE: {jd.get('title', 'Not specified')}

MUST HAVE SKILLS (from JD):
{chr(10).join(f'  - {s}' for s in must_have) if must_have else '  - None'}

GOOD TO HAVE SKILLS:
{chr(10).join(f'  - {s}' for s in good_to_have) if good_to_have else '  - None'}

BONUS SKILLS:
{chr(10).join(f'  - {s}' for s in bonus) if bonus else '  - None'}

NICE TO HAVE: {', '.join(nice_to_have) if nice_to_have else 'None'}

EXPERIENCE REQUIRED: {jd.get('experience_min', 0)}–{jd.get('experience_max', 99)} years
EDUCATION REQUIRED: {jd.get('education_required', 'Not specified')}

SCORING WEIGHTS (used by Python to compute the final overall score):
  Technical : {weights.get('technical', 40)}%
  Experience: {weights.get('experience', 25)}%
  Education : {weights.get('education', 10)}%
  Soft Skills: {weights.get('soft_skills', 15)}%
  Stability : {weights.get('stability', 10)}%

THRESHOLDS:
  Shortlist at or above: {shortlist_threshold}%
  Review at or above   : {review_threshold}%"""

    if min_technical:
        prompt += f"\n  Min technical score  : {min_technical}% (auto PASS if technical < this)"

    prompt += check_block

    if custom:
        prompt += f"\n\nHIRING MANAGER INSTRUCTIONS:\n{custom}"

    prompt += f"""

RESUME TEXT (section-compressed; education is always preserved):
{resume_compressed}

Instructions:
1. Read the MUST HAVE SKILL CHECK section above — those lists are final.
2. Apply the technical-score ceiling that matches the missing count.
3. Score the other 4 categories on their own merits.
4. Provide overall_score and recommendation as your best estimate
   (Python will recalculate from the category scores and weights).
5. Return JSON only — no markdown, no commentary."""

    return prompt
