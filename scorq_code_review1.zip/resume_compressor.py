"""
Resume Compressor — section-aware truncation.

Why this module exists
----------------------
The previous implementation (inline `resume_text[:3000]`) blindly
truncated from the start of the document. Resumes that listed
education at the bottom (very common in experienced-candidate
formats) lost their education section entirely, and the AI scored
education as 0%.

This module:
  1. Splits the resume into labelled sections using common headers.
  2. Always preserves the education section at full length.
  3. Compresses other sections proportionally if the budget is
     exceeded, dropping less-critical sections last.

Section order of importance (kept first when budget allows):
  1. Education          (NEVER dropped, NEVER truncated mid-entry)
  2. Skills / Technical
  3. Experience / Work History
  4. Summary / Profile / Objective
  5. Projects
  6. Certifications
  7. Other (anything unrecognised)
"""
from __future__ import annotations

import re
from typing import Dict, List, Tuple


# Default character budget for the compressed resume sent to the AI.
# 3000 chars ≈ 750 tokens, which leaves plenty of room in the 4o-mini
# context for the system prompt + JSON response.
DEFAULT_BUDGET = 3000


# Section headers we recognise. The order here is the priority order
# used when we have to drop sections to fit the budget — earlier =
# more important = kept longer.
SECTION_PATTERNS: List[Tuple[str, List[str]]] = [
    ("education", [
        r"education",
        r"academic\s+(?:background|qualifications?|history)",
        r"qualifications?",
        r"educational\s+background",
    ]),
    ("skills", [
        r"(?:technical\s+)?skills",
        r"core\s+competencies",
        r"technologies",
        r"tech\s+stack",
        r"expertise",
    ]),
    ("experience", [
        r"(?:work\s+|professional\s+|relevant\s+)?experience",
        r"employment(?:\s+history)?",
        r"work\s+history",
        r"career\s+(?:history|summary)",
    ]),
    ("summary", [
        r"summary",
        r"profile",
        r"objective",
        r"about\s+me",
        r"professional\s+summary",
    ]),
    ("projects", [
        r"projects?",
        r"key\s+projects?",
        r"selected\s+projects?",
    ]),
    ("certifications", [
        r"certifications?",
        r"licenses?\s+(?:and|&)\s+certifications?",
        r"courses?",
        r"training",
    ]),
]


def _build_header_regex() -> re.Pattern:
    """One regex that matches any known section header on its own line."""
    alternatives: List[str] = []
    for _label, patterns in SECTION_PATTERNS:
        alternatives.extend(patterns)
    # Header must be on its own line (allowing surrounding whitespace,
    # optional trailing colon/dash). Case-insensitive.
    joined = "|".join(alternatives)
    return re.compile(
        rf"^\s*(?:{joined})\s*[:\-–—]?\s*$",
        re.IGNORECASE | re.MULTILINE,
    )


_HEADER_RE = _build_header_regex()


def _classify_header(header_text: str) -> str:
    """Return the canonical label for a matched header line."""
    cleaned = header_text.strip().rstrip(":-–—").strip().lower()
    for label, patterns in SECTION_PATTERNS:
        for pat in patterns:
            if re.fullmatch(pat, cleaned, re.IGNORECASE):
                return label
    return "other"


def split_into_sections(resume_text: str) -> Dict[str, str]:
    """
    Split the resume into labelled sections.

    Returns a dict like:
      {
        "preamble":   "<text before any header — usually name/contact>",
        "education":  "<full education section>",
        "skills":     "...",
        ...
        "other":      "<anything under unrecognised headers>",
      }

    Sections that don't appear in the resume are simply absent from
    the dict.
    """
    sections: Dict[str, List[str]] = {}

    # Find all header positions.
    matches = list(_HEADER_RE.finditer(resume_text))

    if not matches:
        # No recognisable structure — treat the whole thing as "other"
        # so the rest of the pipeline still works.
        return {"other": resume_text.strip()}

    # Anything before the first header is the preamble (name, contact, etc.)
    first_start = matches[0].start()
    preamble = resume_text[:first_start].strip()
    if preamble:
        sections.setdefault("preamble", []).append(preamble)

    for i, m in enumerate(matches):
        label = _classify_header(m.group(0))
        body_start = m.end()
        body_end = matches[i + 1].start() if i + 1 < len(matches) else len(resume_text)
        body = resume_text[body_start:body_end].strip()
        if body:
            sections.setdefault(label, []).append(body)

    # Collapse multiple blocks under the same label (e.g. two "Experience" headers)
    return {k: "\n\n".join(v).strip() for k, v in sections.items()}


def compress_resume(resume_text: str, budget: int = DEFAULT_BUDGET) -> str:
    """
    Return a compressed resume that fits within `budget` characters
    and ALWAYS includes the full education section.

    Strategy:
      1. If the whole resume fits, return it unchanged.
      2. Otherwise, split into sections. Reserve the full education
         section first. Then add other sections in priority order.
      3. If any single section is too large for its remaining slice
         of the budget, that section (only) is truncated. Education
         is never the section that gets truncated unless education
         alone is larger than the entire budget — in which case we
         truncate education last and prefer to drop other sections.
    """
    text = resume_text.strip()
    if len(text) <= budget:
        return text

    sections = split_into_sections(text)

    # Priority order for inclusion. Education is forced to be first
    # so it always gets its full character allocation.
    priority = [
        "education",
        "skills",
        "experience",
        "summary",
        "projects",
        "certifications",
        "preamble",
        "other",
    ]

    chunks: List[Tuple[str, str]] = []  # (label, body)
    remaining = budget

    # Pass 1: reserve education in full. If education alone exceeds
    # the budget, take as much as we can BUT still leave a small
    # window (300 chars) for at least the skills section, since both
    # are critical for a credible score.
    edu = sections.get("education", "")
    if edu:
        if len(edu) >= budget - 300:
            edu_slice = edu[: budget - 300].rstrip() + "\n[... education truncated ...]"
            chunks.append(("education", edu_slice))
            remaining = 300
        else:
            chunks.append(("education", edu))
            remaining = budget - len(edu)

    # Pass 2: fill remaining budget with other sections in priority order.
    # Each section gets a header of "\n\n=== LABEL ===\n" (~20 chars overhead).
    HEADER_OVERHEAD = 20
    for label in priority:
        if label == "education":
            continue  # already placed
        body = sections.get(label, "")
        if not body:
            continue
        slot = remaining - HEADER_OVERHEAD
        if slot <= 50:
            # Not enough room for a meaningful chunk — stop adding sections.
            break
        if len(body) <= slot:
            chunks.append((label, body))
            remaining -= len(body) + HEADER_OVERHEAD
        else:
            truncated = body[:slot].rstrip() + f"\n[... {label} truncated ...]"
            chunks.append((label, truncated))
            remaining -= len(truncated) + HEADER_OVERHEAD
            break  # budget consumed

    # Reorder chunks for human-readable output: preamble → summary → skills →
    # experience → projects → certifications → education. Education at the
    # end is fine for the AI; what matters is that it's present.
    output_order = [
        "preamble",
        "summary",
        "skills",
        "experience",
        "projects",
        "certifications",
        "education",
        "other",
    ]
    chunk_map = dict(chunks)

    parts: List[str] = []
    for label in output_order:
        if label not in chunk_map:
            continue
        if label == "preamble":
            parts.append(chunk_map[label])
        else:
            parts.append(f"\n\n=== {label.upper()} ===\n{chunk_map[label]}")

    return "".join(parts).strip()
