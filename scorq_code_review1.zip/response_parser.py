"""
Response Parser — validates AI JSON, then enforces scoring rules.

Responsibilities
----------------
1. parse_score_response(raw_text)
   - Pure parsing. Strip markdown fences, json.loads, clamp scores.
   - Returns the AI's view, possibly malformed-but-recovered.

2. check_must_have_presence(resume_text, must_have_skills)
   - Deterministic, case-insensitive literal check for each Must Have
     skill. The result is the ground truth — it goes into the prompt
     (so the AI can't argue) AND into apply_scoring_rules below
     (so the technical ceiling is enforced regardless of AI output).

3. apply_scoring_rules(parsed, job, resume_text)
   - The single place where Python overrules the AI:
       * Re-runs the literal skill check.
       * Caps the technical score by the ceiling rule.
       * Recalculates overall_score as the weighted average of the
         5 category scores using JD weights. (Fixes Bug 1.)
       * Re-derives the recommendation from JD thresholds.
       * Applies the minimum_technical_score → "PASS" override.
       * Replaces matched_skills / missing_skills with the ground truth.

   Whatever the AI returned is overwritten if it conflicts. This is
   intentional: the AI is good at qualitative reasoning and bad at
   arithmetic and rule-following.
"""
from __future__ import annotations

import json
import re
from typing import Dict, List, Optional


DEFAULT_CATEGORY = {"score": 50, "reasoning": "Could not parse AI response for this category."}

CATEGORIES = ["technical", "experience", "education", "soft_skills", "stability"]

DEFAULT_WEIGHTS = {
    "technical": 40,
    "experience": 25,
    "education": 10,
    "soft_skills": 15,
    "stability": 10,
}


# ───────────────────────────────────────────────────────────────────
# 1. Parsing
# ───────────────────────────────────────────────────────────────────

def parse_score_response(raw_text: str) -> Dict:
    """
    Parse the AI's raw JSON response into a structured dict.
    Returns a safe default if parsing fails so one bad resume
    doesn't break a batch.
    """
    try:
        cleaned = raw_text.strip()
        # Strip accidental markdown code fences.
        cleaned = re.sub(r"^```json\s*", "", cleaned)
        cleaned = re.sub(r"^```\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)

        data = json.loads(cleaned)

        return {
            "overall_score": _clamp(data.get("overall_score", 50)),
            "recommendation": _valid_rec(data.get("recommendation", "REVIEW")),
            "category_scores": {
                cat: _parse_category(data, cat) for cat in CATEGORIES
            },
            "matched_skills": list(data.get("matched_skills") or []),
            "missing_skills": list(data.get("missing_skills") or []),
            "red_flags":      list(data.get("red_flags")      or []),
            "highlights":     list(data.get("highlights")     or []),
            "ai_reasoning":   data.get("ai_reasoning", "") or "",
        }

    except Exception as e:
        return {
            "overall_score": 0,
            "recommendation": "PASS",
            "category_scores": {cat: DEFAULT_CATEGORY.copy() for cat in CATEGORIES},
            "matched_skills": [],
            "missing_skills": [],
            "red_flags": [f"Failed to parse AI response: {str(e)}"],
            "highlights": [],
            "ai_reasoning": f"Scoring failed: {str(e)}",
        }


def _parse_category(data: Dict, key: str) -> Dict:
    cat = (data.get("category_scores") or {}).get(key) or {}
    return {
        "score": _clamp(cat.get("score", 50)),
        "reasoning": cat.get("reasoning") or "No reasoning provided.",
    }


def _clamp(val) -> int:
    try:
        return max(0, min(100, int(round(float(val)))))
    except (TypeError, ValueError):
        return 50


def _valid_rec(val: str) -> str:
    valid = {"SHORTLIST", "REVIEW", "PASS"}
    s = (val or "").upper().strip()
    return s if s in valid else "REVIEW"


# ───────────────────────────────────────────────────────────────────
# 2. Literal Must-Have skill check
# ───────────────────────────────────────────────────────────────────

# Common abbreviations / aliases. A skill is considered present if
# ANY of its aliases appears literally in the resume text. Keep this
# list conservative — only universally accepted abbreviations.
SKILL_ALIASES: Dict[str, List[str]] = {
    "javascript":           ["javascript", "js"],
    "typescript":           ["typescript", "ts"],
    "python":               ["python"],
    "node.js":              ["node.js", "nodejs", "node js"],
    "react.js":             ["react.js", "reactjs", "react"],
    "next.js":              ["next.js", "nextjs"],
    "postgresql":           ["postgresql", "postgres"],
    "microsoft sql server": ["microsoft sql server", "mssql", "sql server"],
    "amazon web services":  ["amazon web services", "aws"],
    "google cloud platform":["google cloud platform", "gcp"],
    "microsoft azure":      ["microsoft azure", "azure"],
    "kubernetes":           ["kubernetes", "k8s"],
    "continuous integration": ["continuous integration", "ci"],
    "machine learning":     ["machine learning", "ml"],
    "artificial intelligence": ["artificial intelligence", "ai"],
    "natural language processing": ["natural language processing", "nlp"],
    "user interface":       ["user interface", "ui"],
    "user experience":      ["user experience", "ux"],
    "object oriented programming": ["object oriented programming", "oop"],
    "test driven development": ["test driven development", "tdd"],
    "power bi":             ["power bi", "powerbi"],
    "microsoft fabric":     ["microsoft fabric", "fabric"],
    "c#":                   ["c#", "c sharp", "csharp"],
    "c++":                  ["c++", "cpp"],
    ".net":                 [".net", "dotnet", "dot net"],
    "asp.net":              ["asp.net", "aspnet", "asp net"],
}


def _normalize(s: str) -> str:
    return (s or "").strip().lower()


def _aliases_for(skill: str) -> List[str]:
    """Return all literal forms to look for. Always includes the
    skill itself; adds known aliases if any."""
    key = _normalize(skill)
    if key in SKILL_ALIASES:
        return SKILL_ALIASES[key]
    return [key]


def _contains_literal(haystack_lower: str, needle: str) -> bool:
    """
    Case-insensitive literal presence check with word-boundary
    enforcement when the needle is plain alphanumeric. Special
    characters like +, #, . defeat \\b, so we fall back to a
    plain substring check for those — but we still require that
    what's around them isn't an unrelated alphanumeric run that
    would make this a false match.

    Examples:
      "javascript"  in "javascript developer" → True (\\b match)
      "js"          in "json"                 → False (\\bjs\\b would fail)
      "c++"         in "c++ programmer"       → True (substring match, ' ' around)
      "c++"         in "c+++"                 → False (trailing + → not isolated)
      "fabric"      in "fabricated"           → False (\\b match fails)
    """
    needle_lower = needle.lower()

    # Try strict word-boundary first when the needle is "regex-friendly".
    if re.fullmatch(r"[a-z0-9][a-z0-9 .]*[a-z0-9]|[a-z0-9]", needle_lower):
        # Word-boundary, with internal spaces/dots escaped.
        pattern = r"\b" + re.escape(needle_lower) + r"\b"
        if re.search(pattern, haystack_lower):
            return True
        # Don't return False yet — for a needle like "node.js" the
        # \b on the trailing 's' is fine, but for safety try the
        # substring fallback below for needles containing dots.

    # Substring fallback for needles with characters that break \b
    # (like +, #, .). We require the surrounding characters to NOT
    # extend the token — i.e. they should be non-[A-Za-z0-9_+#.] so
    # we don't match "c++" inside "c+++".
    idx = 0
    while True:
        pos = haystack_lower.find(needle_lower, idx)
        if pos == -1:
            return False
        before_ok = pos == 0 or not _is_token_char(haystack_lower[pos - 1])
        end = pos + len(needle_lower)
        after_ok = end == len(haystack_lower) or not _is_token_char(haystack_lower[end])
        if before_ok and after_ok:
            return True
        idx = pos + 1


def _is_token_char(ch: str) -> bool:
    """Characters that, if adjacent, mean we're inside a larger token."""
    return ch.isalnum() or ch in "_+#."


def check_must_have_presence(
    resume_text: str,
    must_have_skills: List[str],
) -> Dict[str, List[str]]:
    """
    Deterministic, case-insensitive literal check for each Must Have
    skill. Returns:
        {
            "found":   [skills present in the resume],
            "missing": [skills NOT present in the resume],
        }

    The result is authoritative. The AI is told to use it as-is, and
    apply_scoring_rules uses it to enforce the technical ceiling.
    """
    resume_lower = (resume_text or "").lower()
    found: List[str] = []
    missing: List[str] = []

    for skill in must_have_skills or []:
        skill_name = skill.get("skill", skill) if isinstance(skill, dict) else skill
        aliases = _aliases_for(skill_name)
        if any(_contains_literal(resume_lower, a) for a in aliases):
            found.append(skill_name)
        else:
            missing.append(skill_name)

    return {"found": found, "missing": missing}


# ───────────────────────────────────────────────────────────────────
# 3. Apply scoring rules (Python overrules the AI here)
# ───────────────────────────────────────────────────────────────────

def _ceiling_for_missing(n_missing: int) -> Optional[int]:
    """Return the technical-score ceiling for n_missing missing skills,
    or None if there is no ceiling."""
    if n_missing <= 0:
        return None
    if n_missing == 1:
        return 75
    if n_missing == 2:
        return 50
    if n_missing == 3:
        return 35
    return 20  # 4 or more


def _weighted_overall(category_scores: Dict[str, Dict], weights: Dict) -> int:
    """Weighted average across the 5 categories. Weights that don't
    sum to 100 are normalised to their actual sum so a misconfigured
    JD doesn't silently produce wrong totals."""
    total_weight = 0.0
    weighted_sum = 0.0
    for cat in CATEGORIES:
        w = float(weights.get(cat, DEFAULT_WEIGHTS[cat]) or 0)
        s = float(category_scores.get(cat, {}).get("score", 0) or 0)
        weighted_sum += s * w
        total_weight += w
    if total_weight <= 0:
        # Fallback: equal weighting.
        return int(round(sum(
            float(category_scores.get(c, {}).get("score", 0) or 0) for c in CATEGORIES
        ) / len(CATEGORIES)))
    return int(round(weighted_sum / total_weight))


def _derive_recommendation(
    overall: int,
    technical: int,
    shortlist_threshold: int,
    review_threshold: int,
    minimum_technical_score: Optional[int],
) -> str:
    """Apply the threshold ladder and the minimum-technical override."""
    if minimum_technical_score is not None and technical < minimum_technical_score:
        return "PASS"
    if overall >= shortlist_threshold:
        return "SHORTLIST"
    if overall >= review_threshold:
        return "REVIEW"
    return "PASS"


def apply_scoring_rules(
    parsed: Dict,
    job: Dict,
    resume_text: str,
) -> Dict:
    """
    Take the parsed AI response and enforce all the deterministic
    rules in Python. This is the single place where we overrule the AI.

    Steps:
      1. Recompute the literal Must-Have skill check (do not trust the
         AI's matched/missing lists).
      2. Cap the technical score by the ceiling rule.
      3. Recalculate overall_score from the 5 category scores using
         the JD weights. (Fixes Bug 1.)
      4. Re-derive the recommendation from JD thresholds + the
         minimum_technical_score override.
      5. Replace matched_skills / missing_skills with the ground truth.
      6. Append a transparent audit note to ai_reasoning if we
         changed any score the AI returned.

    Returns a new dict — does not mutate `parsed`.
    """
    result = {
        "overall_score":   parsed.get("overall_score", 0),
        "recommendation":  parsed.get("recommendation", "REVIEW"),
        "category_scores": {
            cat: {
                "score": _clamp(parsed.get("category_scores", {}).get(cat, {}).get("score", 0)),
                "reasoning": parsed.get("category_scores", {}).get(cat, {}).get("reasoning", ""),
            }
            for cat in CATEGORIES
        },
        "matched_skills":  list(parsed.get("matched_skills", []) or []),
        "missing_skills":  list(parsed.get("missing_skills", []) or []),
        "red_flags":       list(parsed.get("red_flags", []) or []),
        "highlights":      list(parsed.get("highlights", []) or []),
        "ai_reasoning":    parsed.get("ai_reasoning", "") or "",
    }

    # Pull JD config.
    weights = job.get("scoring_weights") or DEFAULT_WEIGHTS
    shortlist_threshold = int(job.get("shortlist_threshold") or 75)
    review_threshold    = int(job.get("review_threshold") or 55)
    min_technical       = job.get("minimum_technical_score")
    if min_technical is not None:
        try:
            min_technical = int(min_technical)
        except (TypeError, ValueError):
            min_technical = None

    # Resolve Must Have skills from the JD.
    skill_importance = job.get("skill_importance", {}) or {}
    required_skills = job.get("required_skills", []) or []
    must_have: List[str] = []
    for skill in required_skills:
        name = skill.get("skill", skill) if isinstance(skill, dict) else skill
        imp = skill_importance.get(name, "must")
        if imp == "must":
            must_have.append(name)

    # ---- 1. Ground-truth skill presence -------------------------------
    check = check_must_have_presence(resume_text, must_have)
    found = check["found"]
    missing = check["missing"]
    n_missing = len(missing)

    # Replace AI's matched/missing lists with the ground truth.
    result["matched_skills"] = found
    result["missing_skills"] = missing

    audit_notes: List[str] = []

    # ---- 2. Technical-score ceiling -----------------------------------
    technical_ai = result["category_scores"]["technical"]["score"]
    ceiling = _ceiling_for_missing(n_missing)
    if ceiling is not None and technical_ai > ceiling:
        result["category_scores"]["technical"]["score"] = ceiling
        audit_notes.append(
            f"Technical score capped at {ceiling} "
            f"(AI returned {technical_ai}; {n_missing} Must Have skill(s) missing: "
            f"{', '.join(missing) if missing else 'none'})."
        )
        # Append to the technical reasoning so the UI shows why.
        existing = result["category_scores"]["technical"]["reasoning"]
        cap_note = (
            f" [Python override: {n_missing} Must Have missing → "
            f"capped at {ceiling}.]"
        )
        if cap_note not in existing:
            result["category_scores"]["technical"]["reasoning"] = existing + cap_note

    # ---- 3. Recalculate overall_score (Bug 1) -------------------------
    ai_overall = result["overall_score"]
    overall = _weighted_overall(result["category_scores"], weights)
    result["overall_score"] = overall
    if ai_overall != overall:
        audit_notes.append(
            f"Overall score recalculated: AI returned {ai_overall}, "
            f"weighted average is {overall}."
        )

    # ---- 4. Re-derive recommendation ----------------------------------
    technical_final = result["category_scores"]["technical"]["score"]
    rec = _derive_recommendation(
        overall=overall,
        technical=technical_final,
        shortlist_threshold=shortlist_threshold,
        review_threshold=review_threshold,
        minimum_technical_score=min_technical,
    )
    if rec != result["recommendation"]:
        audit_notes.append(
            f"Recommendation set to {rec} "
            f"(AI suggested {result['recommendation']}; "
            f"thresholds: shortlist≥{shortlist_threshold}, review≥{review_threshold}"
            + (f", min_technical={min_technical}" if min_technical is not None else "")
            + ")."
        )
    result["recommendation"] = rec

    # ---- 5. Audit trail in ai_reasoning -------------------------------
    if audit_notes:
        prefix = "[Python rules applied] " + " ".join(audit_notes)
        result["ai_reasoning"] = (
            prefix + "\n\n" + result["ai_reasoning"]
            if result["ai_reasoning"] else prefix
        )

    return result
